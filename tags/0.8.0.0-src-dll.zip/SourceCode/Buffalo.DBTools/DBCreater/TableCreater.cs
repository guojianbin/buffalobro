using System;
using System.Collections.Generic;
using System.Text;

namespace Buffalo.DBTools.DBCreater
{
    /// <summary>
    /// ������
    /// </summary>
    public class TableCreater
    {

    }
}
