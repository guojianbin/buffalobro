using System;
using System.Collections.Generic;
using System.Text;

namespace Buffalo.DBTools.UIHelper.ModelLoader
{
    /// <summary>
    /// ����ʽ����
    /// </summary>
    public enum ExpressionType
    {
        /// <summary>
        /// �ַ���
        /// </summary>
        String,
        /// <summary>
        /// ����ʽ
        /// </summary>
        Express,
        /// <summary>
        /// �����
        /// </summary>
        Code
    }
}
