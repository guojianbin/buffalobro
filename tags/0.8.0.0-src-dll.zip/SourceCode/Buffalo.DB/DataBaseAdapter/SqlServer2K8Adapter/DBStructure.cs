using System;
using System.Collections.Generic;
using System.Text;
using Buffalo.DB.DbCommon;
using System.Data;


namespace Buffalo.DB.DataBaseAdapter.SqlServer2K8Adapter
{
    /// <summary>
    /// ���ݿ�ṹ������
    /// </summary>
    public class DBStructure : Buffalo.DB.DataBaseAdapter.SqlServer2K5Adapter.DBStructure
    {

        
    }
}
