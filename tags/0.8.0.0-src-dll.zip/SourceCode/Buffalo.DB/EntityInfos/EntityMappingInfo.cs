using System;
using System.Collections.Generic;
using System.Text;
using Buffalo.DB.PropertyAttributes;
using Buffalo.Kernel.FastReflection;

namespace Buffalo.DB.EntityInfos
{
    /// <summary>
    /// ʵ��ӳ���������Ϣ
    /// </summary>
    public class EntityMappingInfo : FieldInfoHandle
    {
        private TableRelationAttribute _mappingInfo;

        
        /// <summary>
        /// �������Ե���Ϣ��
        /// </summary>
        /// <param name="belong">������ʵ��</param>
        /// <param name="getHandle">getί��</param>
        /// <param name="setHandle">setί��</param>
        /// <param name="tableMappingAtt">ӳ���ʶ��</param>
        /// <param name="fieldName">������</param>
        /// <param name="fieldType">��������</param>
        public EntityMappingInfo(Type belong, GetFieldValueHandle getHandle, SetFieldValueHandle setHandle,
            TableRelationAttribute mappingInfo,string fieldName, Type fieldType)
            : base(belong, getHandle, setHandle, fieldType, fieldName)
        {
            this._mappingInfo = mappingInfo;
        }
        /// <summary>
        /// ӳ����Ϣ
        /// </summary>
        public TableRelationAttribute MappingInfo
        {
            get { return _mappingInfo; }
            internal set { _mappingInfo = value; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="belong">����ʵ��</param>
        /// <returns></returns>
        public EntityMappingInfo Copy(Type belong) 
        {
            EntityMappingInfo info = new EntityMappingInfo(belong, GetHandle, SetHandle, _mappingInfo, _fieldName, _fieldType);
            return info;
        }

        /// <summary>
        /// ��Ӧ��������
        /// </summary>
        public string PropertyName
        {
            get
            {
                return _mappingInfo.PropertyName;
            }
        }
        /// <summary>
        /// �Ƿ���������
        /// </summary>
        public bool IsParent
        {
            get
            {
                return _mappingInfo.IsParent;
            }
        }

        /// <summary>
        /// Դ����
        /// </summary>
        public EntityPropertyInfo SourceProperty
        {
            get
            {

                return _mappingInfo.SourceProperty;
            }
        }
        /// <summary>
        /// Ŀ������
        /// </summary>
        public EntityPropertyInfo TargetProperty
        {
            get
            {

                return _mappingInfo.TargetProperty;
            }
        }
    }
}
